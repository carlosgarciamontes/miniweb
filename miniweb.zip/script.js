$(document).ready(function() {
    $(".toggle-btn").click(function() {
        $(this).siblings(".creador").fadeToggle();
    });
});
